let menuVisible = false;
//Función que oculta o muestra el menu
function mostrarOcultarMenu(){
    if(menuVisible){
        document.getElementById("nav").classList ="";
        menuVisible = false;
    }else{
        document.getElementById("nav").classList ="responsive";
        menuVisible = true;
    }
}

function seleccionar(){
    //oculto el menu una vez que selecciono una opcion
    document.getElementById("nav").classList = "";
    menuVisible = false;
}

function descargarZIP() {
    // Cambia 'ruta_al_archivo.zip' por la ruta real de tu archivo ZIP
    var url = 'ruta_al_archivo.zip';
    var a = document.createElement('a');
    a.href = url;
    a.download = 'nombre_del_archivo.zip';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}